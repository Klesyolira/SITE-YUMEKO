// função para mostrar o spinner
function showSpinner() {
  document.getElementById("spinner").classList.add("show");
}

// função para esconder o spinner
function hideSpinner() {
  document.getElementById("spinner").classList.remove("show");
}